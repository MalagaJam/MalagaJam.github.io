# [malagajam.github.io](http://malagajam.com/)

Página web de la asociación MalagaJam

También puedes encontrarnos en...

* [Twitter](https://twitter.com/MalagaJam)
* [Instagram](https://www.instagram.com/malagajam/)
* [itch.io](https://malagajam.itch.io/)
* [Facebook](https://www.facebook.com/malagajam)

¡Y si quieres, puedes unirte a nuestra comunidad en [Discord](https://discord.gg/6Q3DKDT)!

_happy gamedev!_